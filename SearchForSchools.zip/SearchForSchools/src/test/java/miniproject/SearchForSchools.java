package miniproject;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
//import java.util.Scanner;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

public class SearchForSchools {

	public static WebDriver driver;
	public static String url = "https://www.eduvidya.com/";
	private static String browser;
	DataFormatter df = new DataFormatter();
	public static FileInputStream inputFile;
	public static FileOutputStream outputFile;
	public static XSSFWorkbook wb;
	public static XSSFSheet ws;
	public static XSSFRow row;
	public static XSSFCell cell;
	public static CellStyle style; 
	static String excelLocation = "C:\\Users\\2407200\\eclipse-workspace\\SearchForSchools\\src\\test\\resources\\InputOutputBook.xlsx";
	SoftAssert sa = new SoftAssert();
	
//	@BeforeClass
//	public void defaultReport() {
//	for(int i=1;i<=7;i++)
//		try {
//			testFailInExcelReport(i,1);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
	
	public static String selectFromDropDown(String id, String selector) {
		WebElement element = driver.findElement(By.id(id));
		Select select = new Select(element);
		select.selectByVisibleText(selector);
		return select.getFirstSelectedOption().getText();
	}
	
	public static void testPassInExcelReport(int rownum,int colnum) throws IOException {
		inputFile=new FileInputStream(excelLocation);
		wb=new XSSFWorkbook(inputFile);
		ws=wb.getSheet("TestReport");
		row=ws.getRow(rownum);
		cell=row.createCell(colnum);
		
		style=wb.createCellStyle();
		
		style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND); 
				
		cell.setCellStyle(style);
		cell.setCellValue("Pass");
		outputFile = new FileOutputStream(excelLocation);
		wb.write(outputFile);
		wb.close();
		inputFile.close();
		outputFile.close();
	}
	
	public static void testFailInExcelReport(int rownum,int colnum) throws IOException {
		inputFile=new FileInputStream(excelLocation);
		wb=new XSSFWorkbook(inputFile);
		ws=wb.getSheet("TestReport");
		row=ws.getRow(rownum);
		cell=row.createCell(colnum);
		
		style=wb.createCellStyle();
		
		style.setFillForegroundColor(IndexedColors.RED.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND); 
				
		cell.setCellStyle(style);
		cell.setCellValue("Fail");
		outputFile = new FileOutputStream(excelLocation);
		wb.write(outputFile);
		wb.close();
		inputFile.close();
		outputFile.close();
	}
	
	@Parameters({"browser"})
	@Test(priority=0)
	public void testSetupDriver(@Optional("Chrome")String browser) {
//		browser = grabBrowserFromExcel();
		//Setting up respective driver based on input browser
		if(browser.equalsIgnoreCase("Edge")) {
			EdgeOptions options = new EdgeOptions();
			options.setAcceptInsecureCerts(true);//to pass through security of browser
			driver = new EdgeDriver(options);
			System.out.println("Successfully connected driver!");
		}
		else if(browser.equalsIgnoreCase("Chrome")) {
			ChromeOptions options = new ChromeOptions();
			options.setAcceptInsecureCerts(true);//to pass through security of browser
			driver = new ChromeDriver(options);
			System.out.println("Successfully connected driver!");
		}
		//driver.get(url);
		try {
			Assert.assertNotNull(driver,"Enter a valid browser!");
			testPassInExcelReport(1,1);
			testPassInExcelReport(2,1);
		} catch (Exception e) {
			try {
				testFailInExcelReport(1,1);
				testFailInExcelReport(2,1);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
//		sa.assertAll();
	}
	
	@Test(priority=1, dependsOnMethods={"testSetupDriver"})
	public void testGetWebsite() throws IOException {
		driver.get(url);
		try {
			Assert.assertEquals(driver.getCurrentUrl(),url);
			testPassInExcelReport(3,1);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		} catch (Exception e) {
			try {
				testFailInExcelReport(3,1);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
	}
	
	@Test(priority=2, dependsOnMethods= {"testGetWebsite"})
	public void testNavigationToSchools(){
		driver.findElement(By.xpath("//a[text()='Schools']")).click();
		try {
		Assert.assertEquals(driver.getCurrentUrl(),"https://www.eduvidya.com/Schools-in-India.aspx");
		testPassInExcelReport(4,1);
		} catch (Exception e) {
			try {
				testFailInExcelReport(4,1);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(priority=3, dependsOnMethods= {"testNavigationToSchools"})
	public void testCategoryDropDown() {
		String selectedOption = selectFromDropDown("ddl_Category","CBSE");
		try {
			Assert.assertEquals(selectedOption, "CBSE");
			testPassInExcelReport(5,1);
		} catch (Exception e) {
			try {
				testFailInExcelReport(5,1);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(priority=3, dependsOnMethods= {"testNavigationToSchools"})
	public void testCityDropDown() throws IOException {
		String selectedOption = selectFromDropDown("ddl_City","Pune");
		try {
			Assert.assertEquals(selectedOption, "Pune");
			testPassInExcelReport(6,1);
			driver.findElement(By.id("btnSearch")).click();
		} catch (Exception e) {
			try {
				testFailInExcelReport(6,1);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@Test(priority=4, dependsOnMethods= {"testCategoryDropDown","testCityDropDown"})
	public void testResultList() throws IOException {
		WebElement schoolList = driver.findElement(By.xpath("//*[@id='pnllist']/div[2]/ul"));
		try {
			Assert.assertTrue(schoolList.isDisplayed());
			testPassInExcelReport(7,1);
		} catch (Exception e) {
			try {
				testFailInExcelReport(7,1);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
	
	@AfterClass
	public void closeBrowser() {
		driver.close();
	}
	
	
//		public static void main1(String[] args) throws IOException {
//		SearchForSchools sfs = new SearchForSchools();
		 //Driver setup based on user input
//		System.out.println("Enter which browser you would like to proceed through (Chrome or Edge):");
//		Scanner sc = new Scanner(System.in);
//		String browser = sc.nextLine();
//		if(!browser.equalsIgnoreCase("chrome") || !browser.equalsIgnoreCase("edge")) {
//			System.out.println("Please enter a valid browser!");
//			return;
//		}
//		driver = sfs.setupDriver();
//		if(driver==null) {
//			System.out.println("Enter a valid browser!");
//			return;
//		}
		//Implicit wait of 10 seconds initiated for statements from now
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		System.out.println("Opening given link!");
//		driver.get(url);
//		driver.findElement(By.xpath("//a[text()='Schools']")).click();//Finding and clicking 'Schools' element
		
		//Handling both drop downs: 'Category' and 'City' using Select class
//		selectFromDropDown("ddl_Category","CBSE");
//		selectFromDropDown("ddl_City","Pune");
//		driver.findElement(By.id("btnSearch")).click();//Searching
//		System.out.println("Searching...");
		//Display verification of list of schools
//		WebElement schoolList = driver.findElement(By.xpath("//*[@id='pnllist']/div[2]/ul"));
//		if(schoolList.isDisplayed()){
//			System.out.println("Successfully displayed list of schools!");
//		}
//		else
//			System.out.println("List is not displayed!");
//		driver.quit();
//
//	}

}

