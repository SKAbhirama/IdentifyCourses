package testCaseScripts;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import pageObjectClasses.HomePageObject;
import pageObjectClasses.SchoolsPageObject;
import utilFiles.ExcelUtilities;

public class HomePageTest extends DriverSetupClass{
	
	@BeforeClass
	public void setInitialExcelValues () {
		//Method to set all the initial report sheet output cells as "Skipped" by default 
		try {
		for(int i=3;i<=7;i++)
			ExcelUtilities.testSkipInExcelReport(i, driver);//Sets 'Skipped' in the output report in Excel
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testClickOnSchoolsTab() {
		//tests the method to click on "Schools" tab on homepage
		HomePageObject hpo = new HomePageObject(driver);
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(hpo.schoolsTab));//waits until the "Schools" tab is clickable
		hpo.clickOnSchoolsTab();
		SchoolsPageObject spo = new SchoolsPageObject(driver);
		try {
			Assert.assertEquals(driver.getTitle(), spo.schoolsTitle);//Test passes if the title of the page matches the "Schools" page title, else fails
			ExcelUtilities.testPassInExcelReport(3, driver);//Sets 'Pass' in the output report in Excel
		} catch (AssertionError e) {
			try {
				ExcelUtilities.testFailInExcelReport(3, driver);//Sets 'Fail' in the output report in Excel
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
