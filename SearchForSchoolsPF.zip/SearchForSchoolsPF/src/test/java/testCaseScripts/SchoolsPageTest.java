package testCaseScripts;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import pageObjectClasses.SchoolsPageObject;
import utilFiles.ExcelUtilities;

public class SchoolsPageTest extends DriverSetupClass{
	
	SchoolsPageObject spo;
	
	@BeforeClass
	public void initPageObjects() {
		//Function written to initiate the driver passed from the DriverSetup class
		spo = new SchoolsPageObject(driver);
		System.out.println("Driver in SPO: "+driver);//Debugging statement to check whether the driver is passed correctly
	}
	
	@Parameters("category")
	@Test(dependsOnMethods= {"testCaseScripts.HomePageTest.testClickOnSchoolsTab"})
	public void testSelectFromCategoryDropDown(String category) {
		//calls the drop down selecting method from the PageObject Class using the parameter from XML file
		String selectedOption = spo.selectCategoryFromDropDown(category);
		try {
			Assert.assertEquals(selectedOption, "CBSE");//Test passes if the selected option is "CBSE", else fails
			ExcelUtilities.testPassInExcelReport(4, driver);//Sets 'Pass' in the output report in Excel
		} catch (AssertionError e) {
			try {
				ExcelUtilities.testFailInExcelReport(4, driver);//Sets 'Fail' in the output report in Excel
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Parameters("city")
	@Test(priority=1)
	public void testSelectFromCityDropDown(String city) {
		//calls the drop down selecting method from the PageObject Class using the parameter from XML file
		String selectedOption = spo.selectCityFromDropDown(city);
		try {
			Assert.assertEquals(selectedOption, "Pune");//Test passes if the selected option is "Pune", else fails
			ExcelUtilities.testPassInExcelReport(5, driver);//Sets 'Pass' in the output report in Excel
		} catch (AssertionError e) {
			try {
				ExcelUtilities.testFailInExcelReport(5, driver);//Sets 'Fail' in the output report in Excel
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority=2,dependsOnMethods= {"testSelectFromCategoryDropDown","testSelectFromCityDropDown"})
	public void testClickOnSearchBtn() {
		//tests the method to click on "Search" button
		spo.clickOnSearchBtn();
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(spo.resultsList));//Waits until the results are displayed
		try {
			Assert.assertEquals(driver.getCurrentUrl(), spo.resultsUrl);//Test passes if the current URL matches the URL required
			ExcelUtilities.testPassInExcelReport(6, driver);//Sets 'Pass' in the output report in Excel
		} catch (AssertionError e) {
			try {
				ExcelUtilities.testFailInExcelReport(6, driver);//Sets 'Fail' in the output report in Excel
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority=3,dependsOnMethods= {"testClickOnSearchBtn"})
	public void testCheckResultsDisplay() {
		//tests the method to check the results display
		boolean resultStatus = spo.checkResultsDisplay();
		try {
			Assert.assertTrue(resultStatus);//Test passes if the results are displayed, else fails
			ExcelUtilities.testPassInExcelReport(7, driver);//Sets 'Pass' in the output report in Excel
		} catch (AssertionError e) {
			try {
				ExcelUtilities.testFailInExcelReport(7, driver);//Sets 'Fail' in the output report in Excel
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
