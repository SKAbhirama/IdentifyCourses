package testCaseScripts;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import pageObjectClasses.HomePageObject;
import utilFiles.ExcelUtilities;

public class DriverSetupClass {
	
	protected static WebDriver driver;
	
	@Parameters({"browser","url"})
	@BeforeTest
	public void setupDriver(@Optional("Chrome")String browser, String url) {
		//Checks for Chrome browser and sets it up
		if(browser.equalsIgnoreCase("Chrome")) {
			ChromeOptions options = new ChromeOptions();
			options.setAcceptInsecureCerts(true);//to accept security certificates
			driver = new ChromeDriver(options);
		//Checks for Edge browser and sets it up
		} else if(browser.equalsIgnoreCase("Edge")) {
			EdgeOptions options = new EdgeOptions();
			options.setAcceptInsecureCerts(true);//to accept security certificates
			driver = new EdgeDriver(options);
		}
		
		driver.get(url);
		//implicit wait for 10 seconds
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		try {
			Assert.assertNotNull(driver);//Test passes if driver is not null, else fails
			ExcelUtilities.testPassInExcelReport(1, driver);
			ExcelUtilities.testPassInExcelReport(2, driver);//Sets 'Pass' in the output report in Excel
			HomePageObject hpo = new HomePageObject(driver);
			Assert.assertEquals(driver.getTitle(), hpo.homeTitle);//Test passes if correct home page is opened
		} catch (AssertionError e) {
			try {
				ExcelUtilities.testFailInExcelReport(1, driver);
				ExcelUtilities.testFailInExcelReport(2, driver);//Sets 'Fail' in the output report in Excel
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//to close the browser after the test is done
	@AfterTest
	public void closeBrowser() {
		driver.quit();
	}
}
