package utilFiles;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class ExcelUtilities {
	
	public static String fileLocation = "C:\\Users\\2407200\\eclipse-workspace\\SearchForSchoolsPF\\src\\test\\resources\\InputOutputBook.xlsx";
	
	DataFormatter df = new DataFormatter();
	public static FileInputStream inputFile;
	public static FileOutputStream outputFile;
	public static XSSFWorkbook wb;
	public static XSSFSheet ws;
	public static XSSFRow row;
	public static XSSFCell cell;
	public static CellStyle style; 
	
	public static int getColumnBasedOnDriver(WebDriver driver) {
		String[] parts = driver.toString().split(":");
		int colnum = 3;
		if(parts[0].equalsIgnoreCase("ChromeDriver"))
			colnum = 1;
		else if((parts[0].equalsIgnoreCase("EdgeDriver")))
			colnum = 2;
		return colnum;
	}
	
	public static void testSkipInExcelReport(int rownum,WebDriver driver) throws IOException {
		int colnum = getColumnBasedOnDriver(driver);
		inputFile=new FileInputStream(fileLocation);
		wb=new XSSFWorkbook(inputFile);
		ws=wb.getSheet("TestReport");
		row=ws.getRow(rownum);
		cell=row.createCell(colnum);
		
		style=wb.createCellStyle();
		
		style.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND); 
				
		cell.setCellStyle(style);
		cell.setCellValue("Skipped");
		outputFile = new FileOutputStream(fileLocation);
		wb.write(outputFile);
		wb.close();
		inputFile.close();
		outputFile.close();
	}
	
	public static void testPassInExcelReport(int rownum,WebDriver driver) throws IOException {
		int colnum = getColumnBasedOnDriver(driver);
		inputFile=new FileInputStream(fileLocation);
		wb=new XSSFWorkbook(inputFile);
		ws=wb.getSheet("TestReport");
		row=ws.getRow(rownum);
		cell=row.createCell(colnum);
		
		style=wb.createCellStyle();
		
		style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND); 
				
		cell.setCellStyle(style);
		cell.setCellValue("Pass");
		outputFile = new FileOutputStream(fileLocation);
		wb.write(outputFile);
		wb.close();
		inputFile.close();
		outputFile.close();
	}
	
	public static void testFailInExcelReport(int rownum,WebDriver driver) throws IOException {
		int colnum = getColumnBasedOnDriver(driver);
		inputFile=new FileInputStream(fileLocation);
		wb=new XSSFWorkbook(inputFile);
		ws=wb.getSheet("TestReport");
		row=ws.getRow(rownum);
		cell=row.createCell(colnum);
		
		style=wb.createCellStyle();
		
		style.setFillForegroundColor(IndexedColors.RED.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND); 
				
		cell.setCellStyle(style);
		cell.setCellValue("Fail");
		outputFile = new FileOutputStream(fileLocation);
		wb.write(outputFile);
		wb.close();
		inputFile.close();
		outputFile.close();
	}
	
}
