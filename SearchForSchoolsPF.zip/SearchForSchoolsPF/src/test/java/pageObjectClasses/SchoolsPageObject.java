package pageObjectClasses;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SchoolsPageObject {
	
	WebDriver driver;
	WebDriverWait wait;

	public SchoolsPageObject(WebDriver driver) {
		//constructor required to globalise driver and initiate PageFactory class
		this.driver = driver;
		PageFactory.initElements(driver,this);
		wait = new WebDriverWait(driver,Duration.ofSeconds(10));
	}
	
	//Locators required for the "Schools" page
	@FindBy(id="ddl_Category")
	WebElement categoryDD;//Category drop down element
	
	@FindBy(id="ddl_City")
	WebElement cityDD;//City drop down element
	
	@FindBy(id="btnSearch")
	WebElement searchBtn;//Search button element
	
	@FindBy(xpath="//*[@id='pnllist']/div[2]/ul")
	public WebElement resultsList;//returned Results list element
	
	//Variables required to validate the test cases in Test class
	public String schoolsTitle = "Best Schools in India 2023 List, Top Ranking CBSE, ICSE, IB schools";
	public String resultsUrl = "https://www.eduvidya.com/School-Search.aspx?Category=CBSE&CategoryID=1&City=Pune&CityID=2";
	
	//Action Methods
	public String selectCategoryFromDropDown(String category) {
		wait.until(ExpectedConditions.elementToBeClickable(categoryDD));//waits until the drop down is clickable
		Select select = new Select(categoryDD);
		select.selectByVisibleText(category);//chooses the given option
		return select.getFirstSelectedOption().getText();//returns the selected option from the drop down for validation
	}
	
	public String selectCityFromDropDown(String city) {
		wait.until(ExpectedConditions.elementToBeClickable(cityDD));//waits until the drop down is clickable
		Select select = new Select(cityDD);
		select.selectByVisibleText(city);//chooses the given option
		return select.getFirstSelectedOption().getText();//returns the selected option from the drop down for validation
	}
	
	public void clickOnSearchBtn() {
		wait.until(ExpectedConditions.elementToBeClickable(searchBtn));//waits until the search button is clickable
		searchBtn.click();
	}
	
	public boolean checkResultsDisplay() {
		return resultsList.isDisplayed();//returns the display status of the results list for validation
	}
	
}