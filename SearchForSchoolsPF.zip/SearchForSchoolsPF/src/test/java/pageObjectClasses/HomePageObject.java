package pageObjectClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePageObject {
	
	WebDriver driver;

	public HomePageObject(WebDriver driver) {
		//constructor required to globalise driver and initiate PageFactory class
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	//Variable required to validate the test cases in Test class
	public String homeTitle = "Colleges|Schools|Universities|Exams|Courses|Distance Education|India|Eduvidya.com|";
	
	//Locators required for the HomePage
	@FindBy(xpath="//a[text()='Schools']")
	public WebElement schoolsTab;
	
	//Action Methods
	public void clickOnSchoolsTab() {
		schoolsTab.click();
	}
}
